Filelist:
PIC16F15244_layer_plots_release_rev1.pdf : PCB Layer Plots
PIC16F15244_design_documentation_release_rev1.pdf : Design Documentation with Bom
BOM\Bill of Materials Fitted- PIC16F15244_release_rev1.xlsx : BOM, fitted components
ExportSTEP\PIC16F15244_release_rev1.step : 3D Model of PCBA
Gerber\PIC16F15244_release_rev1.GM1 : Gerber files for Board (M1)
Gerber\PIC16F15244_release_rev1.GBS : Gerber files for Bottom Solder
Gerber\PIC16F15244_release_rev1.GBO : Gerber files for Bottom Overlay
Gerber\PIC16F15244_release_rev1.GBL : Gerber files for Bottom Layer
Gerber\PIC16F15244_release_rev1.GP1 : Gerber files for Ground Plane
Gerber\PIC16F15244_release_rev1.GP2 : Gerber files for Power Plane
Gerber\PIC16F15244_release_rev1.GTP : Gerber files for Top Paste
Gerber\PIC16F15244_release_rev1.GTS : Gerber files for Top Solder
Gerber\PIC16F15244_release_rev1.GTL : Gerber files for Top-Layer
Gerber\PIC16F15244_release_rev1.GTO : Gerber files for Top Overlay
NC Drill\PIC16F15244_release_rev1.LDP : Layer Pairs Definition
NC Drill\PIC16F15244_release_rev1.drr : Drill Files Report
NC Drill\PIC16F15244_-RoundHoles_release_rev1.txt : Drill files, ASCII-RoundHoles
NC Drill\PIC16F15244_-SlotHoles_release_rev1.txt : Drill files, ASCII-SlotHoles
NC Drill\PIC16F15244_release_rev1.drl : Drill files, gerber
ODB\PIC16F15244_release_rev1.zip : ODB++ Files
Pick Place\Pick Place for PIC16F15244_release_rev1.txt : Pick and Place file, component placement
Test Points\Assembly Testpoint Report for PIC16F15244_release_rev1.txt : Assembly Testpoint report, txt
Test Points\Assembly Testpoint Report for PIC16F15244_release_rev1.csv : Assembly Testpoint report, csv
